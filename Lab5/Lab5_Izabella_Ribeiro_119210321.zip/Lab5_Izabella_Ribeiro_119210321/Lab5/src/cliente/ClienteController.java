package cliente;

import util.Validador;

import java.util.HashMap;

/** Classe criada para o controle de ações para clientes.
 * **/

public class ClienteController {

    /*Iniciação de classe de Validador que será usado para verificação de entradas*/
    Validador validador;

    /*Map para o armazenamento de clientes cadastrados. */
    HashMap<String, Cliente> clientes;


    /*Construtor*/
    public ClienteController() {
        this.clientes = new HashMap<String, Cliente>();
        this.validador = new Validador();
    }

    /** Método responsável pelo cadastro de clientes
     * @param cpf cpf para a identificação de cada cliente
     * @param  nome nome do cliente
     * @param  localidade local onde o cliente geralmente fica
     * @param email email do cliente.
     * @return o cpf do cliente, quando ocorrer uma ação bem sucedida. */
    public String cadastrarClientes(String cpf, String nome, String email , String localidade) {
        this.validador.validacaoCPF(cpf);
        this.validador.validacaoStringNulaOuVazia(nome, "O NOME");
        this.validador.validacaoStringNulaOuVazia(email, "O EMAIL");
        this.validador.validacaoStringNulaOuVazia(localidade, "A LOCALIDADE");
        Cliente cliente = new Cliente(cpf, nome, email,  localidade);
        this.clientes.put(cliente.getCpf(), cliente);
        return cliente.getCpf();
    }

    /** Método responsável pela exibição de um cliente, de acordo com a sua identificação (cpf)
     * @param cpf para a busca dos dados do cliente.
     * @return mensagem de final de ação (quando sucedida ou não).
     * */
    public String exibirCliente(String cpf) {
        this.validador.validacaoCPF(cpf);
        if (!this.clientes.containsKey(cpf)) {
            return "CLIENTE NÃO ENCONTRADO!";
        }
        return this.clientes.get(cpf).toString();
    }

    /** Método responsável pela exibição de todos os clientes já cadastrados no sistema
     * @return todos os clientes já cadastrados e seus respectivos toStrings. */
    public String mostrarClientesCadastrados(){
        String clientesCadastrados = "";
        if (this.clientes.size() >= 1) {
            for (int i = 0; i < this.clientes.size(); i++) {
                clientesCadastrados += this.clientes.get(i).toString() + " | ";
            }
            return clientesCadastrados;
        }
        return  "Não há clientes ainda.";
    }

    /** Método responsável pelo requerimento de edição de informações do cliente, exceto o campo de cpf, já que é
     * um identificador.
     * @param cpf para saber qual o cliente que será editado.
     * @param campoDeEdicao qual o campo que será editado.
     * @param conteudoDaEdicao novo conteudo que o campo escolhido vai conter.
     */
    public void editarCadastroCliente(String cpf, String campoDeEdicao, String conteudoDaEdicao){
        this.validador.validacaoCPF(cpf);
        this.validador.validacaoStringNulaOuVazia(campoDeEdicao, "O CAMPO DE EDICAO");
        this.validador.validacaoStringNulaOuVazia(conteudoDaEdicao, "O CONTEUDO");
        String campoDeEdicaoFormatado = campoDeEdicao.toUpperCase().trim();

        if (!this.clientes.containsKey(cpf)){
            throw new IllegalArgumentException("O cpf digitado não está presente na lista de clientes.");
        }
        else if (campoDeEdicaoFormatado.equals("CPF")) {
            throw new IllegalArgumentException("O valor do cpf não pode ser alterado, é uma identificação única.");
        }
        else if (campoDeEdicaoFormatado.equals("NOME")) {
            this.clientes.get(cpf).setNome(conteudoDaEdicao);
        }
        else if (campoDeEdicao.equals("LOCALIDADE")) {
            this.clientes.get(cpf).setLocalizacao(conteudoDaEdicao);
        }
        else {
            this.validador.validacaoStringNulaOuVazia(conteudoDaEdicao, "O CONTEUDO ");
            this.clientes.get(cpf).setEmail(conteudoDaEdicao);
        }
    }

    /** Método responsável pela remoção de clientes
     * @param cpf para identificação de qual cliente será removido do sistema.
     * */
    public void removerCliente(String cpf) {
        this.validador.validacaoCPF(cpf);

        if (!this.clientes.containsKey(cpf)) {
          throw new IllegalArgumentException("O cpf digitado não está presente na lista de clientes.");
        }
        this.clientes.remove(cpf);
    }
}
