package cliente;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClienteControllerTest {

    ClienteController controller;

    @BeforeEach
    void setUp() {
        controller = new ClienteController();
    }

    @Test
    void cadastraClientesComValoresCorretos() {
        assertEquals("13786914400",this.controller.cadastrarClientes("13786914400", "João", "izabellasilva@gmail.com", "lsd"));
    }

    @Test
    void cadastraClientesComCPFInválido(){
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("111111111", "Izabella", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("", "Izabella", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente(" ", "Izabella", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("00000000601", "Izabella", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(NullPointerException.class, () -> new Cliente(null, "Izabella", "izabellaribeiro@gmail.com", "splab"));
    }

    @Test
    void cadastraClientesComNomeVazioOuNulo(){
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", " ", "izabellaribeiro@gmail.com", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", null, "izabellaribeiro@gmail.com", "splab"));
    }
    @Test
    void cadastraClientesComEmailVazioOuNulo(){
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", "", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", " ", "splab"));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", null, "splab"));
    }

    @Test
    void cadastraClientesComLocalizacaoVazioOuNulo(){
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", "izabellaribeiro@gmail.com", ""));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", "izabellaribeiro@gmail.com", " "));
        assertThrows(IllegalArgumentException.class, () -> new Cliente("123", "Izabella", "izabellaribeiro@gmail.com", null));
    }

    @Test
    void exibirCliente() {
        this.controller.cadastrarClientes("13786914400", "João", "izabellaribeiro@gmail.com", "lsd");
        assertEquals("João - izabellaribeiro@gmail.com - lsd", this.controller.exibirCliente("13786914400"));
    }

    @Test
    void exibirClienteNaoEncontrado() {
        assertEquals("CLIENTE NÃO ENCONTRADO!", this.controller.exibirCliente("13786914400"));
    }

    @Test
    void exibirClienteNuloOuVazio() {
        assertThrows(IllegalArgumentException.class, () -> this.controller.exibirCliente(""));
        assertThrows(IllegalArgumentException.class, () -> this.controller.exibirCliente(" "));
        assertThrows(NullPointerException.class, () -> this.controller.exibirCliente(null));
    }

    @Test
    void mostrarClientesCadastrados() {
    this.controller.cadastrarClientes("13786914400", "Izabella",
            "izabella.silva@ccc.ufcg.edu.br", "lsd");
        assertEquals("Izabella - izabella.silva@ccc.ufcg.edu.br - lsd",
                this.controller.mostrarClientesCadastrados());
    }

    @Test
    void editarCadastroCliente() {
    }

    @Test
    void removerCliente() {
    }
}